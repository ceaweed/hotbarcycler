package com.example.hotbarcycler;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Client-to-server packet for rotating a single inventory column.
 *
 * The four slots in the column for hotbar slot index s are:
 *   s       (hotbar,  main[s])
 *   s +  9  (row 1,   main[s+9])
 *   s + 18  (row 2,   main[s+18])
 *   s + 27  (row 3,   main[s+27])
 *
 *   next=true  → rotate upward:   hotbar→row3, row1→hotbar, row2→row1, row3→row2
 *   next=false → rotate downward: hotbar→row1, row3→hotbar, row2→row3, row1→row2
 */
public record CycleColumnPayload(int selectedSlot, boolean next) implements class_8710 {

    public static final class_8710.class_9154<CycleColumnPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655("hotbarcycler", "cycle_column"));

    public static final class_9139<class_2540, CycleColumnPayload> CODEC =
            class_9139.method_56438(
                    (value, buf) -> {
                        buf.method_53002(value.selectedSlot());
                        buf.method_52964(value.next());
                    },
                    buf -> new CycleColumnPayload(buf.readInt(), buf.readBoolean())
            );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
