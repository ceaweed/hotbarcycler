package com.example.hotbarcycler;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

/** Replaced CustomPayload — just a channel ID + encoder helper. */
public final class CycleColumnPayload {

    public static final class_2960 ID = new class_2960("hotbarcycler", "cycle_column");

    private CycleColumnPayload() {}

    public static class_2540 encode(int selectedSlot, boolean next) {
        class_2540 buf = PacketByteBufs.create();
        buf.writeInt(selectedSlot);
        buf.writeBoolean(next);
        return buf;
    }
}
