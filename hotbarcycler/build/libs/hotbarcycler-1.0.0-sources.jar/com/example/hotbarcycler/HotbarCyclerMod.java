package com.example.hotbarcycler;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class HotbarCyclerMod implements ModInitializer {

    public static final Logger LOGGER = LoggerFactory.getLogger("hotbarcycler");

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playC2S().register(CycleHotbarPayload.ID, CycleHotbarPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(CycleHotbarPayload.ID, (payload, context) ->
                context.server().execute(() -> {
                    if (payload.next()) rotateNext(context.player());
                    else                rotatePrev(context.player());
                }));

        PayloadTypeRegistry.playC2S().register(CycleColumnPayload.ID, CycleColumnPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(CycleColumnPayload.ID, (payload, context) ->
                context.server().execute(() -> {
                    int slot = payload.selectedSlot();
                    if (slot < 0 || slot > 8) {
                        LOGGER.warn("Invalid column slot {} from {}",
                                slot, context.player().method_5477().getString());
                        return;
                    }
                    if (payload.next()) rotateColumnNext(context.player(), slot);
                    else                rotateColumnPrev(context.player(), slot);
                }));

        LOGGER.info("Hotbar Cycler initialised.");
    }

    // ── Full hotbar rotations ─────────────────────────────────────────────────
    // Using getStack/setStack instead of getMainStacks() for 1.21.1 compatibility

    private static void rotateNext(class_3222 player) {
        class_1661 inv = player.method_31548();
        List<class_1799> hotbar = copySlots(inv, 0, 9);
        moveSlots(inv, 0,  inv, 9,  9);
        moveSlots(inv, 9,  inv, 18, 9);
        moveSlots(inv, 18, inv, 27, 9);
        setSlots(inv, 27, hotbar);
        sync(player);
    }

    private static void rotatePrev(class_3222 player) {
        class_1661 inv = player.method_31548();
        List<class_1799> hotbar = copySlots(inv, 0, 9);
        moveSlots(inv, 0,  inv, 27, 9);
        moveSlots(inv, 27, inv, 18, 9);
        moveSlots(inv, 18, inv, 9,  9);
        setSlots(inv, 9, hotbar);
        sync(player);
    }

    // ── Column rotations ──────────────────────────────────────────────────────

    private static void rotateColumnNext(class_3222 player, int s) {
        class_1661 inv = player.method_31548();
        class_1799 hotbarItem = inv.method_5438(s).method_7972();
        inv.method_5447(s,      inv.method_5438(s +  9).method_7972());
        inv.method_5447(s +  9, inv.method_5438(s + 18).method_7972());
        inv.method_5447(s + 18, inv.method_5438(s + 27).method_7972());
        inv.method_5447(s + 27, hotbarItem);
        sync(player);
    }

    private static void rotateColumnPrev(class_3222 player, int s) {
        class_1661 inv = player.method_31548();
        class_1799 hotbarItem = inv.method_5438(s).method_7972();
        inv.method_5447(s,      inv.method_5438(s + 27).method_7972());
        inv.method_5447(s + 27, inv.method_5438(s + 18).method_7972());
        inv.method_5447(s + 18, inv.method_5438(s +  9).method_7972());
        inv.method_5447(s +  9, hotbarItem);
        sync(player);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static List<class_1799> copySlots(class_1661 inv, int start, int count) {
        List<class_1799> copy = new ArrayList<>(count);
        for (int i = 0; i < count; i++) copy.add(inv.method_5438(start + i).method_7972());
        return copy;
    }

    private static void moveSlots(class_1661 dst, int dstStart,
                                  class_1661 src, int srcStart, int count) {
        for (int i = 0; i < count; i++)
            dst.method_5447(dstStart + i, src.method_5438(srcStart + i).method_7972());
    }

    private static void setSlots(class_1661 inv, int start, List<class_1799> items) {
        for (int i = 0; i < items.size(); i++) inv.method_5447(start + i, items.get(i));
    }

    private static void sync(class_3222 player) {
        player.method_31548().method_5431();
        player.field_7498.method_34252();
    }
}
