package com.example.hotbarcycler;

import com.example.hotbarcycler.screen.HotbarCyclerConfigScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.class_1713;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;

public class HotbarCyclerClient implements ClientModInitializer {

    private static final String CATEGORY = "key.categories.hotbarcycler";

    /**
     * PlayerScreenHandler screen-slot offsets for each inventory section.
     *
     * The player screen handler lays out slots as:
     *   0       = crafting result
     *   1-4     = crafting grid
     *   5-8     = armor
     *   9-35    = main inventory rows 1-3  (PlayerInventory.main[9..35])
     *   36-44   = hotbar                  (PlayerInventory.main[0..8])
     *   45      = offhand
     *
     * SlotActionType.SWAP with button 0-8 swaps slotId ↔ hotbar[button].
     * Three such swaps chain-cycle the four rows with zero stacking risk.
     */
    private static final int HOTBAR = 36;  // unused directly but kept for clarity
    private static final int ROW1   = 9;
    private static final int ROW2   = 18;
    private static final int ROW3   = 27;

    private static class_304 nextHotbarKey;
    private static class_304 prevHotbarKey;
    private static class_304 nextColumnKey;
    private static class_304 prevColumnKey;
    private static class_304 openSettingsKey;
    private static class_304 toggleColumnPreviewKey;
    private static class_304 toggleRowIndicatorKey;
    private static class_304 toggleInventoryOverlayKey;

    private static int     currentPage             = 0;
    private static boolean columnPreviewVisible    = true;
    private static boolean rowIndicatorVisible     = true;
    private static boolean inventoryOverlayVisible = false;

    public static int     getCurrentPage()            { return currentPage; }
    public static boolean isColumnPreviewVisible()    { return columnPreviewVisible; }
    public static boolean isRowIndicatorVisible()     { return rowIndicatorVisible; }
    public static boolean isInventoryOverlayVisible() { return inventoryOverlayVisible; }

    @Override
    public void onInitializeClient() {
        HotbarCyclerConfig.get();

        nextHotbarKey             = reg("key.hotbarcycler.next");
        prevHotbarKey             = reg("key.hotbarcycler.prev");
        nextColumnKey             = reg("key.hotbarcycler.column_next");
        prevColumnKey             = reg("key.hotbarcycler.column_prev");
        openSettingsKey           = reg("key.hotbarcycler.open_settings");
        toggleColumnPreviewKey    = reg("key.hotbarcycler.toggle_column_preview");
        toggleRowIndicatorKey     = reg("key.hotbarcycler.toggle_row_indicator");
        toggleInventoryOverlayKey = reg("key.hotbarcycler.toggle_inventory_overlay");

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            currentPage             = 0;
            inventoryOverlayVisible = false;
            columnPreviewVisible    = HotbarCyclerConfig.get().showColumnPreview;
            rowIndicatorVisible     = HotbarCyclerConfig.get().showRowIndicator;
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null) return;

            while (openSettingsKey.method_1436())
                client.method_1507(new HotbarCyclerConfigScreen(client.field_1755));
            while (toggleColumnPreviewKey.method_1436())
                columnPreviewVisible = !columnPreviewVisible;
            while (toggleRowIndicatorKey.method_1436())
                rowIndicatorVisible = !rowIndicatorVisible;
            while (toggleInventoryOverlayKey.method_1436())
                inventoryOverlayVisible = !inventoryOverlayVisible;

            while (nextHotbarKey.method_1436()) {
                rotateRows(client, true);
                currentPage = (currentPage + 1) % 4;
            }
            while (prevHotbarKey.method_1436()) {
                rotateRows(client, false);
                currentPage = (currentPage - 1 + 4) % 4;
            }

            int sel = client.field_1724.method_31548().field_7545;
            while (nextColumnKey.method_1436())
                rotateColumn(client, sel, true);
            while (prevColumnKey.method_1436())
                rotateColumn(client, sel, false);
        });
    }

    /**
     * Rotates all 9 inventory columns by one row.
     *
     * Uses SlotActionType.SWAP: clickSlot(syncId, slotId, button=col, SWAP, player)
     * swaps the item at screen slot [slotId] with hotbar slot [col].
     *
     * next=true  (↑): hotbar ← row1 ← row2 ← row3 ← old hotbar
     *   swap(row3[c], c) → hotbar[c]=row3, row3[c]=hotbar
     *   swap(row2[c], c) → hotbar[c]=row2, row2[c]=old row3 ✓
     *   swap(row1[c], c) → hotbar[c]=row1 ✓, row1[c]=old row2 ✓
     *   result: hotbar=row1, row1=row2, row2=row3, row3=old hotbar ✓
     *
     * next=false (↓): hotbar ← row3 ← row2 ← row1 ← old hotbar
     *   swap(row1[c], c) → hotbar[c]=row1, row1[c]=hotbar
     *   swap(row2[c], c) → hotbar[c]=row2, row2[c]=old row1 ✓
     *   swap(row3[c], c) → hotbar[c]=row3 ✓, row3[c]=old row2 ✓
     *   result: hotbar=row3, row3=row2, row2=row1, row1=old hotbar ✓
     */
    private static void rotateRows(class_310 client, boolean next) {
        int syncId = client.field_1724.field_7498.field_7763;
        for (int c = 0; c < 9; c++) {
            if (next) {
                swap(client, syncId, ROW3 + c, c);
                swap(client, syncId, ROW2 + c, c);
                swap(client, syncId, ROW1 + c, c);
            } else {
                swap(client, syncId, ROW1 + c, c);
                swap(client, syncId, ROW2 + c, c);
                swap(client, syncId, ROW3 + c, c);
            }
        }
    }

    /**
     * Rotates a single inventory column (same SWAP chain, one column only).
     */
    private static void rotateColumn(class_310 client, int col, boolean next) {
        int syncId = client.field_1724.field_7498.field_7763;
        if (next) {
            swap(client, syncId, ROW3 + col, col);
            swap(client, syncId, ROW2 + col, col);
            swap(client, syncId, ROW1 + col, col);
        } else {
            swap(client, syncId, ROW1 + col, col);
            swap(client, syncId, ROW2 + col, col);
            swap(client, syncId, ROW3 + col, col);
        }
    }

    /**
     * Fires a SWAP click: swaps screen slot [slotId] with hotbar slot [hotbarIndex].
     * clickSlot() updates the client inventory immediately and sends a
     * ClickSlotC2SPacket so the server stays in sync — no custom networking needed.
     */
    private static void swap(class_310 client, int syncId, int slotId, int hotbarIndex) {
        client.field_1761.method_2906(
                syncId, slotId, hotbarIndex, class_1713.field_7791, client.field_1724);
    }

    private static class_304 reg(String id) {
        return KeyBindingHelper.registerKeyBinding(new class_304(
                id, class_3675.class_307.field_1668, class_3675.field_16237.method_1444(), CATEGORY));
    }
}