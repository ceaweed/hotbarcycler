package com.example.hotbarcycler;

import com.example.hotbarcycler.screen.HotbarCyclerConfigScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_304;
import net.minecraft.class_3675;

public class HotbarCyclerClient implements ClientModInitializer {

    private static final String CATEGORY = "key.categories.hotbarcycler";

    private static class_304 nextHotbarKey;
    private static class_304 prevHotbarKey;
    private static class_304 nextColumnKey;
    private static class_304 prevColumnKey;
    private static class_304 openSettingsKey;
    private static class_304 toggleColumnPreviewKey;
    private static class_304 toggleRowIndicatorKey;
    private static class_304 toggleInventoryOverlayKey;

    private static int     currentPage             = 0;
    private static boolean columnPreviewVisible    = true;
    private static boolean rowIndicatorVisible     = true;
    private static boolean inventoryOverlayVisible = false;

    public static int     getCurrentPage()            { return currentPage; }
    public static boolean isColumnPreviewVisible()    { return columnPreviewVisible; }
    public static boolean isRowIndicatorVisible()     { return rowIndicatorVisible; }
    public static boolean isInventoryOverlayVisible() { return inventoryOverlayVisible; }

    @Override
    public void onInitializeClient() {
        HotbarCyclerConfig.get();

        nextHotbarKey             = reg("key.hotbarcycler.next");
        prevHotbarKey             = reg("key.hotbarcycler.prev");
        nextColumnKey             = reg("key.hotbarcycler.column_next");
        prevColumnKey             = reg("key.hotbarcycler.column_prev");
        openSettingsKey           = reg("key.hotbarcycler.open_settings");
        toggleColumnPreviewKey    = reg("key.hotbarcycler.toggle_column_preview");
        toggleRowIndicatorKey     = reg("key.hotbarcycler.toggle_row_indicator");
        toggleInventoryOverlayKey = reg("key.hotbarcycler.toggle_inventory_overlay");

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            currentPage             = 0;
            inventoryOverlayVisible = false;
            columnPreviewVisible    = HotbarCyclerConfig.get().showColumnPreview;
            rowIndicatorVisible     = HotbarCyclerConfig.get().showRowIndicator;
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null) return;

            while (openSettingsKey.method_1436())
                client.method_1507(new HotbarCyclerConfigScreen(client.field_1755));
            while (toggleColumnPreviewKey.method_1436())
                columnPreviewVisible = !columnPreviewVisible;
            while (toggleRowIndicatorKey.method_1436())
                rowIndicatorVisible = !rowIndicatorVisible;
            while (toggleInventoryOverlayKey.method_1436())
                inventoryOverlayVisible = !inventoryOverlayVisible;

            // ── send() now takes (Identifier, PacketByteBuf) ──────────────
            while (nextHotbarKey.method_1436()) {
                ClientPlayNetworking.send(CycleHotbarPayload.ID, CycleHotbarPayload.encode(true));
                currentPage = (currentPage + 1) % 4;
            }
            while (prevHotbarKey.method_1436()) {
                ClientPlayNetworking.send(CycleHotbarPayload.ID, CycleHotbarPayload.encode(false));
                currentPage = (currentPage - 1 + 4) % 4;
            }

            int sel = client.field_1724.method_31548().field_7545;
            while (nextColumnKey.method_1436())
                ClientPlayNetworking.send(CycleColumnPayload.ID, CycleColumnPayload.encode(sel, true));
            while (prevColumnKey.method_1436())
                ClientPlayNetworking.send(CycleColumnPayload.ID, CycleColumnPayload.encode(sel, false));
        });
    }

    private static class_304 reg(String id) {
        return KeyBindingHelper.registerKeyBinding(new class_304(
                id, class_3675.class_307.field_1668, class_3675.field_16237.method_1444(), CATEGORY));
    }
}