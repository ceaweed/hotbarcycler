package com.example.hotbarcycler;

import com.example.hotbarcycler.screen.HotbarCyclerConfigScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;

public class HotbarCyclerClient implements ClientModInitializer {

    private static final class_304.class_11900 CATEGORY =
            class_304.class_11900.method_74698(class_2960.method_60655("hotbarcycler", "hotbarcycler"));

    // ── Keybindings ───────────────────────────────────────────────────────────
    private static class_304 nextHotbarKey;
    private static class_304 prevHotbarKey;
    private static class_304 nextColumnKey;
    private static class_304 prevColumnKey;
    private static class_304 openSettingsKey;
    private static class_304 toggleColumnPreviewKey;
    private static class_304 toggleRowIndicatorKey;
    private static class_304 toggleInventoryOverlayKey;

    // ── Runtime state ─────────────────────────────────────────────────────────
    /** Which of the 4 inventory rows is currently active in the hotbar. */
    private static int currentPage = 0;

    /**
     * Runtime visibility for Column Preview.
     * Toggled by toggleColumnPreviewKey; initialised from config on join.
     */
    private static boolean columnPreviewVisible = true;

    /**
     * Runtime visibility for Row Indicator.
     * Toggled by toggleRowIndicatorKey; initialised from config on join.
     */
    private static boolean rowIndicatorVisible = true;

    /**
     * Whether the Inventory Overlay is currently shown.
     * Toggled by toggleInventoryOverlayKey; always starts hidden.
     */
    private static boolean inventoryOverlayVisible = false;

    // ── Getters ───────────────────────────────────────────────────────────────
    public static int     getCurrentPage()             { return currentPage; }
    public static boolean isColumnPreviewVisible()     { return columnPreviewVisible; }
    public static boolean isRowIndicatorVisible()      { return rowIndicatorVisible; }
    public static boolean isInventoryOverlayVisible()  { return inventoryOverlayVisible; }

    // ── Init ──────────────────────────────────────────────────────────────────

    @Override
    public void onInitializeClient() {
        HotbarCyclerConfig.get();   // create config file on first launch

        nextHotbarKey = reg("key.hotbarcycler.next");
        prevHotbarKey = reg("key.hotbarcycler.prev");
        nextColumnKey = reg("key.hotbarcycler.column_next");
        prevColumnKey = reg("key.hotbarcycler.column_prev");
        openSettingsKey          = reg("key.hotbarcycler.open_settings");
        toggleColumnPreviewKey   = reg("key.hotbarcycler.toggle_column_preview");
        toggleRowIndicatorKey    = reg("key.hotbarcycler.toggle_row_indicator");
        toggleInventoryOverlayKey = reg("key.hotbarcycler.toggle_inventory_overlay");

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            currentPage            = 0;
            inventoryOverlayVisible = false;
            // Sync runtime visibility from saved config on world join
            columnPreviewVisible = HotbarCyclerConfig.get().showColumnPreview;
            rowIndicatorVisible  = HotbarCyclerConfig.get().showRowIndicator;
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null) return;

            while (openSettingsKey.method_1436()) {
                client.method_1507(new HotbarCyclerConfigScreen(client.field_1755));
            }
            while (toggleColumnPreviewKey.method_1436()) {
                columnPreviewVisible = !columnPreviewVisible;
            }
            while (toggleRowIndicatorKey.method_1436()) {
                rowIndicatorVisible = !rowIndicatorVisible;
            }
            while (toggleInventoryOverlayKey.method_1436()) {
                inventoryOverlayVisible = !inventoryOverlayVisible;
            }

            while (nextHotbarKey.method_1436()) {
                ClientPlayNetworking.send(new CycleHotbarPayload(true));
                currentPage = (currentPage + 1) % 4;
            }
            while (prevHotbarKey.method_1436()) {
                ClientPlayNetworking.send(new CycleHotbarPayload(false));
                currentPage = (currentPage - 1 + 4) % 4;
            }

            int sel = client.field_1724.method_31548().method_67532();
            while (nextColumnKey.method_1436()) {
                ClientPlayNetworking.send(new CycleColumnPayload(sel, true));
            }
            while (prevColumnKey.method_1436()) {
                ClientPlayNetworking.send(new CycleColumnPayload(sel, false));
            }
        });
    }

    private static class_304 reg(String id) {
        return KeyBindingHelper.registerKeyBinding(new class_304(
                id, class_3675.class_307.field_1668, class_3675.field_16237.method_1444(), CATEGORY));
    }
}
