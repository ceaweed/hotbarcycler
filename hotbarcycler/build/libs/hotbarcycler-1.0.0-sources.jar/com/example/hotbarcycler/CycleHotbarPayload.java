package com.example.hotbarcycler;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Client-to-server packet that carries a single direction:
 *   true  = Next  (rotate rows upward   → row 9-17 becomes the new hotbar)
 *   false = Prev  (rotate rows downward → row 27-35 becomes the new hotbar)
 */
public record CycleHotbarPayload(boolean next) implements class_8710 {

    public static final class_8710.class_9154<CycleHotbarPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655("hotbarcycler", "cycle"));

    public static final class_9139<class_2540, CycleHotbarPayload> CODEC =
            class_9139.method_56438(
                    (value, buf) -> buf.method_52964(value.next()),
                    buf -> new CycleHotbarPayload(buf.readBoolean())
            );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
