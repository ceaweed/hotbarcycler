package com.example.hotbarcycler;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

/** Replaced CustomPayload — just a channel ID + encoder helper. */
public final class CycleHotbarPayload {

    public static final class_2960 ID = new class_2960("hotbarcycler", "cycle");

    private CycleHotbarPayload() {}

    public static class_2540 encode(boolean next) {
        class_2540 buf = PacketByteBufs.create();
        buf.writeBoolean(next);
        return buf;
    }
}
